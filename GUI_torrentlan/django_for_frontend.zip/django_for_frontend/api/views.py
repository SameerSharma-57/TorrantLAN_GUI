from django.shortcuts import render
import sys
import os
# Create your views here.
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..','..')))
from main import rows_at_depth
print(rows_at_depth(1))

def getFolderListAtDepth(request,depth):
    print(rows_at_depth(depth=depth))
    return HttpResponse('hi')